# mruby-x68k v0.4.0

Sharp X68000 / Human68k 向け `mruby.x` の実験リリースです。

## 主な変更

- `mruby-x68k-stdio` を廃止し、OS系APIを `mruby-x68k-os`、X68000ハードウェア系APIを `mruby-x68k-hardware` に分離しました。
- 配布バイナリを `bin/` 以下へ整理しました。
  - `mruby.x`: フル版 `.rb` 実行環境
  - `mrbc.x`: X68000上で動く `.rb` to `.mrb` コンパイラ
  - `mrb.x`: フル版 `.mrb` 実行専用VM
  - `mrb-os.x`: OS-only版 `.mrb` 実行専用VM
- `mrb.x` / `mrb-os.x` は mruby/c ではなく、mruby本体の RiteBinary `.mrb` 実行専用VMであることを明記しました。

- SEGA 3B/6B パッド読み取りAPIを追加しました。
  - `X68k::Joy.sega3b`, `sega3b_raw`
  - `X68k::Joy.sega6b`, `sega6b_raw`, `sega6b_scan_raw`
- AJOY.X 経由の CyberStick / アナログジョイスティック入力APIを追加しました。
  - `X68k::Ajoy.read_raw`, `read`, `trigger_mask`, `buttons`
  - スロットル反転、ボタンプリセット、A/A+/B/B+ の扱いを整理しています。
- CyberStick / AJOY.X 入力を使ったワイヤーフレーム風フライトサンプル `cyber_flight.rb` を追加しました。
- グラフィック描画ページを切り替える `X68k::Screen.apage` を追加しました。
  - `X68k::Screen.vpage` と組み合わせることで、簡易的なページ切り替え描画ができます。
  - mode 10 の色指定について、実機確認に基づくメモを追加しています。
- VSync / Raster / Timer-D / OPM の割り込みpoll APIと確認用サンプルを整理しました。
  - Ruby VM を割り込みハンドラから直接触らず、C側カウンタをRuby側からpollする方針です。
- Ruby のバッククォート構文で外部コマンドの標準出力を文字列として取得できるようにしました。
  - 現時点では暫定導入です。
  - コマンドの標準出力を一時ファイルへリダイレクトし、それを文字列として読み戻します。

## 同梱ファイル

- `bin/mruby.x`
  - X68000 / Human68k 向けのフル版 mruby 実行ファイル
- `bin/mrbc.x`
  - X68000 / Human68k 上で `.rb` から `.mrb` を生成するコンパイラ
- `bin/mrb.x`
  - `.mrb` 実行専用のフル版VM。mruby/c ではなく、mruby本体のRiteBinary実行用VMです。
- `bin/mrb-os.x`
  - `.mrb` 実行専用のOS-only版VM。mruby/c ではなく、mruby本体のRiteBinary実行用VMです。
- `samples/`
  - Rubyサンプルと Z-MUSIC 用サンプル音源
- `README-release.txt`
- `release-notes-v0.4.0.md`
- `LICENSE`
- `THIRD_PARTY_NOTICES.md`
- `third_party/libzm2/COPYING`
- `third_party/libzm2/COPYING.RUNTIME`

## mruby/c との関係

`bin/mrb.x` / `bin/mrb-os.x` は mruby/c ではありません。
通常の mruby 本体からビルドした、RiteBinary `.mrb` 実行専用の軽量VMです。
`.rb` ソースを直接実行する機能や mruby コンパイラは含まないため、`.rb` から `.mrb` への変換は `bin/mruby.x` または `bin/mrbc.x` で行ってください。

また、`.mrb` は同じ mruby バージョンと互換性のあるgem/API構成で実行する前提です。
X68000ハードウェアAPIを使う `.mrb` は `bin/mrb.x`、OS系APIだけを使う `.mrb` は `bin/mrb-os.x` での実行を想定しています。

## バージョン表示

`mruby --version` または `mruby -v` で、`mruby-x68k` 側のバージョンも表示します。

```text
mruby-x68k 0.4.0
target: X68000 / Human68k
mruby 4.0.0 (2026-04-20)
```

## サンプル

基本サンプル:

```text
mruby graph_demo.rb
mruby joy_spr.rb
mruby maze_chase.rb
mruby maze_chase.rb wait=2
mruby maze_chase.rb noaudio
```

Z-MUSIC の確認:

```text
mruby zm_test.rb ZMD/simplebgm.ZMD
mruby zm_game_audio.rb
```

SEGA 3B/6B パッドの確認:

```text
mruby joy_sega3b_test.rb
mruby joy_sega6b_test.rb
mruby joy_sega6b_scan.rb
```

CyberStick / AJOY.X の確認:

```text
AJOY.X
mruby ajoy_chk.rb
mruby cyber_flight.rb
```

バッククォートの確認:

```text
mruby backquote_chk.rb
mruby backquote_chk.rb "dir *.rb"
```

## 注意事項

- このリリースは実験版です。
- Z-MUSIC サンプルを鳴らすには Z-MUSIC.X が常駐している必要があります。
- libzm2 の利用条件は `THIRD_PARTY_NOTICES.md` を確認してください。
- AJOY.X は同梱していません。CyberStick / アナログジョイスティックサンプルを使う場合は別途常駐させてください。
- SEGA 3B/6B パッドは、TH/Select を X68000 ジョイスティック pin 8 へ配線した変換アダプタを前提にしています。
- バッククォート対応は暫定導入です。実装方式や制約は今後見直す可能性があります。
- このリポジトリには mruby 本体、xdev68k、elf2x68k、GCC、newlib、エミュレータ本体、Z-MUSIC.X、AJOY.X は含めていません。
- `bin/` 以下の実行ファイルを再配布する場合は、mruby のライセンス表記もあわせて確認してください。
